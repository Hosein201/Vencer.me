(function ($) {
  "use strict"


  var typed = new Typed('.element', {
    strings: ["این اولین جمله است.", "این دومین جمله است."],
    typeSpeed: 50
  });




})(jQuery);